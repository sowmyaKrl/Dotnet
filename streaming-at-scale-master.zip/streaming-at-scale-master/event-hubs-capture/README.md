# Redirection Notice

Sample has been moved here:

[eventhubs-capture](../eventhubs-capture)