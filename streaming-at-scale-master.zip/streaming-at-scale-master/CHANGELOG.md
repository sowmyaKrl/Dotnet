## Streaming At Scale on Azure Changelog

<a name="1.0.0"></a>
# 1.0.0 (2019-07-xx)

First release 

*Features*
* Nine End-To-End samples to create stream processing solution in Azure

*Bug Fixes*
* None

*Breaking Changes*
* None
