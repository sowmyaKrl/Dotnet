# Redirection Notice

Sample has been moved here:

[eventhubs-functions-cosmosdb](../eventhubs-functions-cosmosdb)